import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync('index.html', 'utf8');
const app = fs.readFileSync('assets/js/app.js', 'utf8');
const css = fs.readFileSync('assets/css/app.css', 'utf8');
const builder = fs.readFileSync('scripts/prepare-android-web.mjs', 'utf8');
const workflow = fs.readFileSync('.github/workflows/main.yml', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const manifest = JSON.parse(fs.readFileSync('manifest.webmanifest', 'utf8'));
const inventory = JSON.parse(fs.readFileSync('design-reference/MASTER-SCREEN-INVENTORY-v99.0.json', 'utf8'));

test('v99.0 release identity is synchronized across package, HTML, manifest and cache', () => {
  assert.equal(pkg.version, '1.99.0-v99.0');
  assert.match(html, /1\.99\.0-v99\.0/);
  assert.equal(manifest.version, pkg.version);
  assert.match(fs.readFileSync('service-worker.js','utf8'), /sa-calculator-v99-0-rebuilt-workspace-v990/);
});

test('primary navigation is ordered Calculator, Tools, History, Saved, Settings', () => {
  const nav = html.slice(html.indexOf('<nav class="bottom-navigation"'), html.indexOf('</nav>'));
  const destinations = [...nav.matchAll(/data-bottom-nav="([^"]+)"/g)].map(m => m[1]);
  const labels = [...nav.matchAll(/<span>(Calculator|Tools|History|Saved|Settings)<\/span>/g)].map(m => m[1]);
  assert.deepEqual(destinations, ['calc','tools','history','favorites','settings']);
  assert.deepEqual(labels, ['Calculator','Tools','History','Saved','Settings']);
});

test('Tools directory has exactly 17 unique tool cards across four task groups', () => {
  const cards = [...html.matchAll(/data-tool-screen="([^"]+)"/g)].map(m => m[1]);
  assert.equal(cards.length, 17);
  assert.equal(new Set(cards).size, 17);
  const screenIds = [...html.matchAll(/id="screen-([^"]+)"/g)].map(m => m[1]);
  for (const destination of cards) assert.ok(screenIds.includes(destination), `missing screen destination: ${destination}`);
  assert.deepEqual(Object.keys(inventory.tool_categories).sort(), ['Convert','Daily','Finance','Math']);
  assert.equal(inventory.tool_count, 17);
  for (const group of ['Convert','Finance','Math','Daily']) {
    assert.match(html, new RegExp(`data-tools-group="${group}"`));
    assert.match(html, new RegExp(`data-tools-group-heading="${group}"`));
  }
});

test('tool search filters by intent and hides empty groups without breaking delegated navigation', () => {
  assert.match(app, /data-tools-group-heading/);
  assert.match(app, /groupCards/);
  assert.match(app, /card\.hidden = !match/);
  assert.match(app, /event\.target\.closest\('\[data-tool-screen\]'\)/);
  assert.match(app, /switchScreen\(destination\)/);
});

test('tool cards communicate the task and retain accessible names', () => {
  assert.equal((html.match(/class="premium-tool-description"/g) || []).length, 17);
  assert.equal((html.match(/aria-label="Open /g) || []).filter(x => x).length >= 17, true);
  assert.match(html, /placeholder="Search a tool or task"/);
});

test('one canonical stylesheet is loaded and build script does not concatenate historical patch files', () => {
  assert.match(html, /href="assets\/css\/app\.css"/);
  assert.doesNotMatch(html, /rebuild-v98\.\d+\.css/);
  assert.doesNotMatch(builder, /cssSources/);
  assert.match(builder, /one canonical stylesheet copied/i);
  assert.match(css, /SA CALCULATOR v99\.0 — CANONICAL WORKSPACE DESIGN/);
});

test('canonical UI covers compact and expanded layouts, light mode and reduced motion', () => {
  assert.match(css, /@media\(min-width:600px\)/);
  assert.match(css, /@media\(max-width:360px\)/);
  assert.match(css, /prefers-reduced-motion:reduce/);
  assert.match(css, /data-theme="light"/);
  assert.match(css, /min-height:76px/);
});

test('Android workflow verifies v99.0, runs tests, builds web and APK, and uploads artifact', () => {
  assert.match(workflow, /1\.99\.0-v99\.0/);
  assert.match(workflow, /npm test/);
  assert.match(workflow, /npm run build:web/);
  assert.match(workflow, /npx cap add android/);
  assert.match(workflow, /npm run android:brand/);
  assert.match(workflow, /npm run android:apk/);
  assert.match(workflow, /actions\/upload-artifact@v4/);
});

test('Android web bundle copies the exact canonical source assets and rejects stale versions', () => {
  assert.match(builder, /pkg\.version !== '1\.99\.0-v99\.0'/);
  assert.match(builder, /assets\/css\/app\.css/);
  assert.match(builder, /id="premium-tools-grid"/);
  assert.match(builder, /www/);
});
