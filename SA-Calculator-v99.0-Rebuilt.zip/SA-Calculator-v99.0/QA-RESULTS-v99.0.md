# QA results — SA Calculator v99.0

## Source checks completed
- 87/87 automated tests passed (calculation, scientific formatting, currency freshness/refresh, tool engines, server security, service-worker navigation and v99.0 architecture).
- JavaScript syntax: 8/8 source and build scripts passed `node --check`.
- CSS parsing: 0 parser errors across the canonical stylesheet.
- Android web bundle: generated successfully; the build script verified 13 required assets.
- Generated HTML and CSS are byte-identical to canonical source files.
- GitHub Actions YAML: both supplied workflow copies parsed successfully and are byte-identical.
- Tool directory: 17 unique tool cards, each linked to an existing screen, organized into 4 groups.
- Release identity synchronized: `1.99.0-v99.0` in package, HTML and manifest; service-worker cache namespace bumped.
- Source ZIP integrity checked after packaging.

## Rebuilt information architecture
Calculator → Tools → History → Saved → Settings.
Tools are organized by task intent: Convert (3), Finance (6), Math (4), Daily (4). Search matches tool names, task descriptions and category; empty groups hide while filtering.

## Not claimed as completed
- GitHub Actions execution and actual APK artifact generation.
- Installation and runtime validation on a physical Android device.
- TalkBack/manual accessibility audit.
- Screenshot comparison across OEM devices and font/display scaling settings.
- Real-device frame-time, memory and sustained performance measurements.

A passing source test suite does not prove zero bugs or zero lag on every Android device. Those claims require device testing.
