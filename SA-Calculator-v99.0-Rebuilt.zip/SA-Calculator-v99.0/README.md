# SA Calculator v99.0 — Rebuilt Workspace

## Release identity
- Package: `1.99.0-v99.0`
- Android application ID: `com.sacalculator.app`
- Build source: this directory only
- Runtime stylesheet: `assets/css/app.css` (single canonical stylesheet)
- Web bundle: generated at `www/` by `npm run build:web`

## New information architecture
Primary navigation is ordered by task frequency and app hierarchy:
1. **Calculator** — fast everyday calculation and expression preview.
2. **Tools** — searchable directory with four intent-based groups:
   - Convert: Currency Converter, Unit Converter, Fuel Efficiency.
   - Finance: Discount, Sales Tax, Loan, Savings, Tip, Unit Price.
   - Math: Percentage, Grade Average, Hex Converter, Scientific Calculator.
   - Daily: Body Metrics, Date Calculator, Fuel Cost, World Time.
3. **History** — calculation history and existing row actions.
4. **Saved** — saved/favorite tools.
5. **Settings** — appearance, themes, preferences and app controls.

Individual tools open focused detail screens and return to the originating top-level destination. Search and category filters work on the same 17 tool records; there are no duplicate shortcut records.

## UI system
- Premium graphite/charcoal base, soft neutral surfaces and indigo action accents.
- Teal is reserved for positive/result emphasis in relevant history/result contexts.
- Grouped tool directory with concise task descriptions, category filters and search.
- Dedicated scientific and converter layouts remain distinct from the basic keypad.
- Light and dark themes are retained.
- Safe-area, reduced-motion, keyboard viewport and focus-visible behavior are retained.
- 48dp minimum interactive targets are used where compatible with the existing keypad geometry.

## Build locally
```bash
npm install
npm test
npm run build:web
npx cap add android
npm run android:brand
npm run android:apk
```

## GitHub Actions
Use `.github/workflows/main.yml` or upload the supplied `SA-Calculator-v99.0-Android-Workflow.yml` as `.github/workflows/main.yml`. The workflow verifies source identity, runs tests, creates the web bundle, adds the Android platform, applies branding, builds the debug APK and uploads it as an artifact.

## Validation boundary
Source regression tests and web-bundle generation can be run in this environment. A successful CI APK build is not the same as physical-device visual validation. Installation, TalkBack checks, screen-by-screen screenshots, touch latency and sustained performance must be verified on actual Android devices before claiming bug-free or lag-free behavior.
