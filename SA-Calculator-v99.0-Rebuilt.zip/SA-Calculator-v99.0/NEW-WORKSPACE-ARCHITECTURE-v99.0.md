# v99.0 — New workspace architecture

## What changed at the content level
The previous release presented the tool collection as one long undifferentiated card stream. v99.0 changes the information architecture: the Tools destination is now a directory grouped by the user's intent rather than by the historical order in which features were added.

### Top-level navigation
Calculator → Tools → History → Saved → Settings

These five destinations remain peers. The ordering places the primary calculator first, tool discovery second, and supporting destinations after them. Individual tool screens are child destinations, not additional bottom tabs.

### Tools discovery model
- Search answers “what do I need?” across tool name, category and task description.
- Category chips narrow the directory without navigating away.
- Group headings and groups disappear when filters have no matching tools.
- Each card states both the tool name and its practical job.
- One canonical card per tool avoids duplicated actions and inconsistent favorites.
- Opening a tool preserves the originating top-level destination and existing screen scroll restoration.

### Category map
| Group | Tools | User intent |
|---|---|---|
| Convert | Currency, Unit, Fuel Efficiency | Change one quantity or denomination into another |
| Finance | Discount, Sales Tax, Loan, Savings, Tip, Unit Price | Make a price, payment or money decision |
| Math | Percentage, Grade Average, Hex, Scientific | Solve a numeric or technical problem |
| Daily | Body Metrics, Date, Fuel Cost, World Time | Answer a practical everyday question |

## Clean source/build structure
- One canonical stylesheet: `assets/css/app.css`.
- The build script copies the canonical source tree into `www`; it does not concatenate a chain of versioned CSS patch files.
- `www` is generated and is not shipped as a second stale copy in the source archive.
- Service-worker cache namespace is bumped for v99.0.
- Android workflow selects this release identity, runs regression tests and creates an APK artifact.

## Retained behavior
Existing calculation engines, currency providers, localization data, favorites/history persistence, converter selectors, scientific modes and tool routes are retained. This is a content/navigation/UI rebuild, not a claim that every underlying engine was rewritten.
